#include <iostream>
#include "StoreAdapter.h"
#include "NaviStateManager/NaviStateManager.h"
#include "NaviStateManager/State/TurnOnNaviState.h"
#include "NaviStateManager/State/TurnOffNaviState.h"
#include "NaviStateManager/State/RpRunningNaviState.h"

int main()
{
	CNaviOperator *pOperator = CNaviOperator::GetInstance();

	CTurnOnNaviState* pTurnOnState = new CTurnOnNaviState();
	CTurnOffNaviState* pTurnOffState = new CTurnOffNaviState();
	CRPRunningNaviState* pRpRunningState = new CRPRunningNaviState();

	if (pOperator)
	{
		// OFF �϶�
		std::cout << std::endl << "---------------- OFF ------------------ " << std::endl;
		pOperator->SetState(pTurnOffState);
		pOperator->OnAction(eRPRunning);
		pOperator->OnAction(eTurnOff);
		pOperator->OnAction(eTurnOn);


		// ON �϶�
		std::cout << std::endl << "---------------- ON ------------------ " << std::endl;
		pOperator->SetState(pTurnOnState);
		pOperator->OnAction(eRPRunning);
		pOperator->OnAction(eTurnOff);
		pOperator->OnAction(eTurnOn);

		// RP RUNNING �϶�
		std::cout << std::endl << "---------------- RP RUNNING ------------------ " << std::endl;
		pOperator->SetState(pRpRunningState);
		pOperator->OnAction(eRPRunning);
		pOperator->OnAction(eTurnOff);
		pOperator->OnAction(eTurnOn);
	}

	delete pTurnOnState;
	delete pTurnOffState;
	delete pRpRunningState;


	return 0;
}