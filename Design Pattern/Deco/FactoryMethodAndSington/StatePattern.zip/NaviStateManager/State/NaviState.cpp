#include "NaviState.h"

CNaviState::CNaviState()
{

}

CNaviState::~CNaviState()
{

}

void CNaviState::TurnOn()
{

}

void CNaviState::TurnOff()
{

}

void CNaviState::RPRunning()
{

}

